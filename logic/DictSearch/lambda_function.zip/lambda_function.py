import re
import requests

# トークン化の関数
def tokenize(text):
    # 1. 基本的な正規化（不要な空白を削除）
    text = text.strip()
    
    # 2. アポストロフィの扱い（l'homme や d'accord を分ける）
    text = re.sub(r"(\w+)([’'])(\w+)", r"\1\2 \3", text)
    
    # 3. 特殊なハイフンの扱い（aujourd'hui のような例）
    text = re.sub(r"(\w)-(\w)", r"\1 - \2", text)
    
    # 4. 句読点を分離
    text = re.sub(r"([.,!?;:()])", r" \1 ", text)
    
    # 5. スペースでトークンに分割
    tokens = text.split()
    return tokens

# フランス語Wiktionary APIで意味を取得する関数
def search_wiktionary(word, language="fr"):
    """
    Wiktionary APIを使用して単語の意味を取得する（フランス語対応）。
    
    :param word: 検索する単語
    :param language: 言語コード（'fr' フランス語）
    :return: 単語の意味（テキスト形式）
    """
    url = f"https://{language}.wiktionary.org/w/api.php"
    params = {
        "action": "query",
        "format": "json",
        "titles": word,
        "prop": "extracts",
        "explaintext": True
    }

    response = requests.get(url, params=params)
    if response.status_code != 200:
        return f"Error: Failed to fetch data for '{word}'. HTTP Status Code: {response.status_code}"

    data = response.json()
    pages = data.get("query", {}).get("pages", {})
    for page_id, page_content in pages.items():
        if page_id == "-1":  # ページが見つからない場合
            return f"Aucune définition trouvée pour '{word}'"
        return page_content.get("extract", "Aucune définition disponible.")
    
    return "Erreur: Réponse inattendue du serveur."

# Lambdaハンドラー関数
def lambda_handler(event, context):
    # イベントからテキストを取得
    text = event.get("text", "")
    if not text:
        return {
            "statusCode": 400,
            "body": "Aucun texte fourni"
        }
    
    # トークン化処理
    tokens = tokenize(text)
    
    # 各トークンの意味を取得
    token_definitions = {}
    for token in tokens:
        definition = search_wiktionary(token, language="fr")  # フランス語版Wiktionaryを利用
        token_definitions[token] = definition
    
    # 結果を返却
    return {
        "statusCode": 200,
        "body": {
            "original_text": text,
            "tokens": tokens,
            "definitions": token_definitions
        }
    }
